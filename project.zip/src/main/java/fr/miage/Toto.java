package fr.miage;
public class Toto{}
