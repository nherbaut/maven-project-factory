package toto.miage;
public class Titi{}
